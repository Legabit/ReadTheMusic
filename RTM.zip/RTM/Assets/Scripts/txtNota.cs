﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class txtNota : MonoBehaviour {
	Text txt;
	public string notiz;

	// Use this for initialization
	void Start () {
		txt = gameObject.GetComponent<Text>(); 
		txt.text="Nota : ";
	}
	
	// Update is called once per frame
	void Update () {
		txt.text="Nota : " + notiz;  
	}
}
