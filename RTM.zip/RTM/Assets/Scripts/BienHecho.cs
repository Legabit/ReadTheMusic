﻿using UnityEngine;
using System.Collections;

public class BienHecho : MonoBehaviour {
    Animator anim;
	// Use this for initialization
	void Start () {
        Vector2 fuera = new Vector2(-30,0);
        this.transform.position = fuera;
        anim = this.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        if (GameObject.Find("Manager").GetComponent<Bandera>().flag)
        {
            this.transform.position = new Vector2(-12,0);
            anim.SetTrigger("Completo");
        }
	}
}
