﻿using UnityEngine;
using System.Collections;

public class Return : MonoBehaviour {
	Vector2 origin;
	public bool released;
	// Use this for initialization
	void Start () {
		origin = this.transform.position;
	}
	void OnMouseDown(){
		released=false;
        
    }
	void OnMouseUp(){
		released=true;
	}
	// Update is called once per frame
	void Update () {
		if(released){
			transform.position=origin;
		}
    }
}
