﻿using UnityEngine;
using System.Collections;

public class Dialogo : MonoBehaviour {
    public Vector3 posici = new Vector3(0.7F, -1.5F, 0);
    Vector2 fuera = new Vector2(-30, 0);
    // Use this for initialization
    void Start () {      
        this.transform.position = fuera;
    }
	
	// Update is called once per frame
	void Update () {
        if (GameObject.Find("Supercapitan").transform.position == posici)
        {
            this.transform.position = new Vector2(7.76F, 2.51F);
        }
        else
        {
            this.transform.position = fuera;
        }
    }
}
