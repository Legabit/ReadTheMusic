﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class LoadLvl : MonoBehaviour {
	public void NextLvl(int lvl){
		SceneManager.LoadScene (lvl);
	}
}