﻿using UnityEngine;
using System.Collections;

public class Bandera : MonoBehaviour {
    public bool flag = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (GameObject.Find("Col_Titulo").GetComponent<Check>().checks && GameObject.Find("Col_Columna").GetComponent<Check>().checks && GameObject.Find("Col_Img01").GetComponent<Check>().checks && GameObject.Find("Col_Img02").GetComponent<Check>().checks)
            flag = true;
    }
}
