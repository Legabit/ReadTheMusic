﻿using UnityEngine;
using System.Collections;

public class checkPos : MonoBehaviour {
	public float posY;
	public string lanota;
	// Use this for initialization
	void Start () {
		posY = transform.position.y;
		
	}
	// Update is called once per frame
	void Update () {
		posY = transform.position.y;
		if (GameObject.Find ("re1").GetComponent<Transform> ().position.y == posY)
			lanota = "re";
		if (GameObject.Find ("mi1").GetComponent<Transform> ().position.y == posY)
			lanota = "mi";
		if (GameObject.Find ("fa1").GetComponent<Transform> ().position.y == posY)
			lanota = "fa";
		if (GameObject.Find ("sol1").GetComponent<Transform> ().position.y == posY)
			lanota = "sol";
		if (GameObject.Find ("la1").GetComponent<Transform> ().position.y == posY)
			lanota = "la";
		if (GameObject.Find ("si1").GetComponent<Transform> ().position.y == posY)
			lanota = "si";
		if (GameObject.Find ("do1").GetComponent<Transform> ().position.y == posY)
			lanota = "do";				
		if (GameObject.Find ("re2").GetComponent<Transform> ().position.y == posY)
			lanota = "re";					
		if (GameObject.Find ("mi2").GetComponent<Transform> ().position.y == posY)
			lanota = "mi";						
		if (GameObject.Find ("fa2").GetComponent<Transform> ().position.y == posY)
			lanota = "fa";								
		if (GameObject.Find ("sol2").GetComponent<Transform> ().position.y == posY)
			lanota = "sol";
		GameObject.Find ("txt").GetComponent<txtNota> ().notiz = lanota;
	}
}
