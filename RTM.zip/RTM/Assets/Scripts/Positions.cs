﻿using UnityEngine;
using System.Collections.Generic;

public class Positions : MonoBehaviour {
	public GameObject boton;
	public GameObject canvas;
	public List<Transform> posicion;
	public List<GameObject> buttons;
	GameObject button, correct;
	Transform pos;
	int r1,r2;
	void OnTriggerEnter2D(Collider2D col){
		r1 = Random.Range (0, posicion.Count);
		pos = posicion [r1];
		button = Instantiate (boton);
		correct = button;
		correct.tag= "Correct";
		button.transform.SetParent (canvas.transform, false);
		button.transform.position = pos.position;
		posicion.Remove (posicion [r1]);
		for (int i = 0; i <= posicion.Count; i++) {
			r1 = Random.Range (0, posicion.Count);
			r2 = Random.Range (0, buttons.Count);
			pos = posicion [r1];
			button = Instantiate (buttons[r2]);
			button.tag= "Incorrect";
			button.transform.SetParent (canvas.transform, false);
			button.transform.position = pos.position;
			posicion.Remove (posicion [r1]);
			buttons.Remove (buttons [r2]);
		}
	}
}
