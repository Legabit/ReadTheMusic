﻿using UnityEngine;
using System.Collections;

public class FijarPosicion : MonoBehaviour {

	void OnCollisionEnter2D(Collision2D other)
    {

    }
}
