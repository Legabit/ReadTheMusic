﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Check : MonoBehaviour {
	public GameObject target;
    public bool checks = false;    
	bool correct=false;
	// Use this for initialization
	void Start () {

    }
	
	// Update is called once per frame
	void Update () {
        if (target.transform.position == this.transform.position)
        {
            //this.GetComponent<Collider2D>().enabled = false;
            //target.GetComponent<Collider2D>().enabled = false;
            checks = true;
        }
    }


    void OnTriggerEnter2D(Collider2D colisionador){
        if (colisionador == target.GetComponent<Collider2D>())
        {
            correct = true;
        }
    }

	void OnTriggerStay2D(Collider2D colisionador){
		if(correct){
            colisionador.transform.position = this.transform.position;
            colisionador.transform.rotation = this.transform.rotation;
            colisionador.GetComponent<Return>().enabled = false;
        }
	}void OnTriggerExit2D(Collider2D otro)
    {
        otro.GetComponent<Return>().enabled = true;
    }
}