﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

public class Answer : MonoBehaviour {
	public GameObject txt;

	public void Check(GameObject yolo){
		if (GameObject.FindGameObjectWithTag("Correct")) {
			txt = GameObject.Find("Text");
			txt.GetComponent<Text>().text="Correct";
		} else if(GameObject.FindGameObjectWithTag("Incorrect")){
			txt = GameObject.Find("Text");
			txt.GetComponent<Text>().text="Incorrect";
		}
	}
}