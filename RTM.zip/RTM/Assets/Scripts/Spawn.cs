﻿using UnityEngine;
using System.Collections;

public class Spawn : MonoBehaviour {
	public float[] posiciones;
	public GameObject nota;
	public GameObject canvas;
	// Use this for initialization
	void Start () {
		int selected = Random.Range (0, posiciones.Length);
		GameObject note = Instantiate (nota,new Vector2(80,posiciones[selected]),Quaternion.identity) as GameObject;
		note.transform.SetParent (canvas.transform, false);
	}
}