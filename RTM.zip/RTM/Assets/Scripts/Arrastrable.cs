﻿using UnityEngine;
using System.Collections;

public class Arrastrable : MonoBehaviour {
    void OnMouseDrag()
    {
        Vector2 point = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        Vector2 posicion = Camera.main.ScreenToWorldPoint(point);
        transform.position = posicion;
    }
}
